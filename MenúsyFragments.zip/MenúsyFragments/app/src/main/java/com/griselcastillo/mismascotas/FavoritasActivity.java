package com.griselcastillo.mismascotas;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.griselcastillo.mismascotas.adapter.MascotaAdaptador;
import com.griselcastillo.mismascotas.pojo.Mascota;

import java.util.ArrayList;

public class FavoritasActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    public MascotaAdaptador adaptador;
    ArrayList<Mascota> mascotasFavoritas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favoritas);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        recyclerView= findViewById(R.id.rvMascotas);
        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(lm);

        obtenerMascotasFavoritas();
        inicializarAdaptador();
    }

    public void inicializarAdaptador(){
        adaptador= new MascotaAdaptador(mascotasFavoritas, this);
        recyclerView.setAdapter(adaptador);
    }
    public void obtenerMascotasFavoritas(){
        mascotasFavoritas=new ArrayList<>();
        mascotasFavoritas.add(new Mascota("Camilo",7,R.drawable.camilo));
        mascotasFavoritas.add(new Mascota("Caramelo",6,R.drawable.caramelo));
        mascotasFavoritas.add(new Mascota("Conchi",5,R.drawable.conchi));
        mascotasFavoritas.add(new Mascota("Lolito",5,R.drawable.lolito));
        mascotasFavoritas.add(new Mascota("Manchas",4,R.drawable.manchas));

    }
}

