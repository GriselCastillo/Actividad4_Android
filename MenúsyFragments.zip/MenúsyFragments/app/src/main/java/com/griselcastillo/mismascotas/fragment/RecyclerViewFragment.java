package com.griselcastillo.mismascotas.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.griselcastillo.mismascotas.R;
import com.griselcastillo.mismascotas.adapter.MascotaAdaptador;
import com.griselcastillo.mismascotas.pojo.Mascota;

import java.util.ArrayList;

public class RecyclerViewFragment extends Fragment {

    ArrayList<Mascota> listadoMascotas;
    private RecyclerView recyclerView;
    public MascotaAdaptador adaptador;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.fragment_recycler_view, container,false);
        recyclerView = v.findViewById(R.id.rvMascotas);
        LinearLayoutManager lm = new LinearLayoutManager(getContext());
        lm.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(lm);
        obtenerListadoMascotas();
        inicializarAdaptador();

        return v;
    }
    public void inicializarAdaptador() {
        adaptador = new MascotaAdaptador(listadoMascotas, getActivity());
        recyclerView.setAdapter(adaptador);
    }
    public void obtenerListadoMascotas() {
        listadoMascotas = new ArrayList<>();
        listadoMascotas.add(new Mascota("Camilo", 1, R.drawable.camilo));
        listadoMascotas.add(new Mascota("Caramelo", 2, R.drawable.caramelo));
        listadoMascotas.add(new Mascota("Conchi", 3, R.drawable.conchi));
        listadoMascotas.add(new Mascota("Lolito", 4, R.drawable.lolito));
        listadoMascotas.add(new Mascota("Manchas", 5, R.drawable.manchas));
        listadoMascotas.add(new Mascota("Pelusa", 6, R.drawable.pelusa));
        listadoMascotas.add(new Mascota("Zeus", 7, R.drawable.zeus));
    }
}
