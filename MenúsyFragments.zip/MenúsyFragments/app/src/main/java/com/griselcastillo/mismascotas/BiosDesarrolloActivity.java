package com.griselcastillo.mismascotas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.griselcastillo.mismascotas.pojo.InformacionDesarrollador;

public class BiosDesarrolloActivity extends AppCompatActivity {
    TextView tvNombreBio;
    TextView tvLugarNacimientoBio;
    TextView tvPrograma;
    TextView tvFechaDesarrolloBio;
    TextView tvVersionBio;
    TextView tvSobreMi;
    ImageView imgFotoBio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bios_desarrollo);
        tvNombreBio=findViewById(R.id.tvNombreBio);
        tvLugarNacimientoBio=findViewById(R.id.tvLugarNacimientoBio);
        InformacionDesarrollador bioDesarrollador=getInformacionBIO();
        tvNombreBio.setText(bioDesarrollador.getNombre());
        tvLugarNacimientoBio.setText(bioDesarrollador.getLugarNacimiento());
    }
    public  InformacionDesarrollador getInformacionBIO(){
        InformacionDesarrollador bioDesarrollador=new InformacionDesarrollador();
        bioDesarrollador.setNombre(getResources().getString(R.string.bio_mi_nombre));
        bioDesarrollador.setLugarNacimiento(getResources().getString(R.string.bio_mi_lugar_nac));
        return bioDesarrollador;

    }
}
